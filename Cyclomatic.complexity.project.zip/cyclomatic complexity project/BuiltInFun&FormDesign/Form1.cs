﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Data.OleDb;
namespace SCC
{
 public partial class Form1 : Form
    {
        ArrayList al = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }
        String textfile1 = "";
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
                textfile1 = openFileDialog1.FileName;
            StreamReader sr = new StreamReader(textfile1);
            Stack s = new Stack();

            bool inFunction = false;
            String FunToken, calling = " ", called = " ", str, chainstr = " ", funname = " ";

            char[] de = { ' ', ')', '{', '}', '\t', '\n', '+', '-', '*', '/', '%', '=', '>', '_', '!', '&', '|' };
            char[] de1 = { ' ', ')', '{', '}', '\t', '\n', '+', '-', '*', '/', '%', '=', '>', '_', '!' };
            while (sr.Peek() > 0)
            {

                str = sr.ReadLine();
                rtbFile.Text += str + "\n";
                str = str.Replace(" (", "(");
                String[] sp = str.Split(de);

                if (inFunction == false && str.Contains('(') && !str.EndsWith(";"))
                {
                    foreach (string tokens in sp)
                    {

                        if (tokens.Contains('('))
                        {
                            FunToken = tokens.Substring(0, tokens.IndexOf('('));
                            //  MessageBox.Show("x=" + x);
                            if (!(al.Contains(tokens)))
                            {
                                inFunction = true;
                                funname = FunToken;
                                if (FunToken != " ")
                                {
                                    calling = FunToken;
                                    chainstr = FunToken + "$";
                                    if (str.Contains('{'))
                                        str = str.Substring(str.IndexOf('{'), str.Length - str.IndexOf('{'));
                                    else str = " ";
                                }
                            }
                        }
                        if (inFunction)
                            break;
                    }
                }


                if (str.Contains('{'))
                    s.Push('{');
                if (inFunction == true && str.Contains('('))
                {

                    sp = str.Split(de);
                    foreach (string tokens in sp)
                    {
                        if (tokens.Contains('('))
                        {
                            FunToken = tokens.Substring(0, tokens.IndexOf('('));
                            if (FunToken == "if" || FunToken == "while" || FunToken == "for" || FunToken == "case")
                            {
                                int aoCount = 0;

                                String[] andor = str.Split(de1);
                                foreach (string t in andor)

                                    if (tokens.Contains("&&") || tokens.Contains("||"))
                                        aoCount++;
                                findkeywords(funname, FunToken, aoCount);

                            }
                                //findkeywords(funname,FunToken,aoCount);private void findkeywords(string funname, string funtoken,int aocount)

                                if (!(al.Contains(FunToken)) && !isOperator(FunToken) && FunToken != " " && FunToken != "'")



                                    chainstr = FunToken + "$" + called;
                            }
                        }
                    }

                    if (str.Contains('}'))
                    {
                        //Stack s;
                        s.Pop();
                        if (s.Count == 0)
                        {
                            inFunction = false;
                            //add chainstr to global function calls 
                            Global.bl.Add(chainstr);
                            //trim the string called
                            called.Trim();

                            //insert calling and called into the database
                            //insert(calling,called);
                            chainstr = " ";
                            calling = " ";
                            called = " ";
                        
                    }
                }// end of while
            }
        }//end of private
  private void findkeywords(string funname, string funtoken, int aocount)
        {
            string connectionString = null;
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\SCC11.accdb;Persist Security Info=False";
            OleDbConnection cn = new OleDbConnection(connectionString);
            OleDbCommand cmd;
            DataSet ds = new DataSet();
            string str = "Select * from SCC3 where filename='" + textfile1 + "' and funname='" + funname + "' and funtoken='" + funtoken + "'";
            OleDbDataAdapter adp = new OleDbDataAdapter(str, cn);
            ds.Clear();
            adp.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                string str1 = "insert into SCC3 values('" + textfile1 + "','" + funname + "','" + funtoken + "','" + (aocount + 1) + "')";
                cmd = new OleDbCommand(str1, cn);
                cn.Open();
                // cmd.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
                cn.Close();
               

            }

      

            

        
            else
            {


                int c = int.Parse(ds.Tables[0].Rows[0][3].ToString());
                c += aocount + 1;
                string str1 = "update SCC3 set aocount  =" + c + " where filename='" + textfile1 + "' and funname='" + funname + "' and funtoken='" + funtoken + "'";
                cmd = new OleDbCommand(str1, cn);
                
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
  }


  private void SCC(string funname, int CC)
  {
      }
 
        public  string called { get; set; }

        public object tokens{ get; set; }

        private void populateArrayList()
       {
            string line;
            StreamReader sr = new StreamReader(@"C:\keywords.txt");

            while (sr.Peek() > 0)
            {
                line = sr.ReadLine();
                line = line.Trim();
                al.Add(line);
                // MessageBox.Show(line);
             }
        }
        private bool isOperator(string tokens)
        {
            switch (tokens)
            {
                case "+":
                case "-":
                case "*":
                case "/":
                case "%":
                case "=":
                    return true;
                default: return false;
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
            populateArrayList();

            delRecords();
        }
        private void delRecords()
        {
            string connectionString = null;
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\SCC11.accdb;Persist Security Info=False";
            OleDbConnection cn = new OleDbConnection(connectionString);
            OleDbCommand cmd;
            string str1 = "delete from SCC3";
            cmd = new OleDbCommand(str1, cn);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
        string connectionString = null;
      connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\SCC11.accdb;Persist Security Info=False";
      OleDbConnection cn = new OleDbConnection(connectionString);
      OleDbCommand cmd;
      DataSet ds = new DataSet();
      string str = "Select filename,funname,sum(aocount) from SCC3 groupby filename,funname";
      OleDbDataAdapter adp = new OleDbDataAdapter(str, cn);
      ds.Clear();
      adp.Fill(ds);
      for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
      {
          int c = int.Parse(ds.Tables[0].Rows[i][2].ToString());
          string str1 = "insert into SCC4 values ('" + ds.Tables[0].Rows[i][0].ToString() + "','" + ds.Tables[0].Rows[i][1].ToString() + "'," + c + 1 + ")";




          cmd = new OleDbCommand(str1, cn);
          //string str = "insert into SCC4 values SELECT filename, funname, sum(aocount) FROM scc3 GROUP BY filename, funname";
          cn.Open();
          cmd.ExecuteNonQuery();
          cn.Close();
      }
        }
         
     
 }

}


    







                   

        













