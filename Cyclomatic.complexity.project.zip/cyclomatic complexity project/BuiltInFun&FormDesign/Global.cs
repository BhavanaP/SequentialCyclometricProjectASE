﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace SCC
{
    class Global
    {
       public static ArrayList bl = new ArrayList();
       
       

    }
}
 