﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace keywordCount
{
    public partial class charts : Form
    {
        public charts()
        {
            InitializeComponent();
        }

        private void charts_Load(object sender, EventArgs e)
        {
            // Data arrays.
            //string[] seriesArray = { "Cats", "Dogs","tigers" };
            //int[] pointsArray = { 1, 2 ,8};

            // Set palette.
            this.chart1.Palette =  ChartColorPalette.SeaGreen;
            this.chart2.Palette = ChartColorPalette.SeaGreen;
            // Set title.
            this.chart1.Titles.Add("Individual Function Calls");
            this.chart2.Titles.Add("Chain of Function Calls");
            // Add series.
            
            for (int i = 0; i < Globals.funname.Length; i++)
            {
                // Add series.
                Series series = this.chart1.Series.Add(Globals.funname[i]);
               
                // Add point.
                series.Points.Add(Globals.simpleCyclo[i]);

            }
                      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <Globals.funname.Length; i++)
            {
                // Add series.
                Series series = this.chart2.Series.Add(Globals.funname[i]);
            
                // Add point.
                series.Points.Add(Globals.chainCyclo[i]);
            }
        }
    }
}
