﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Data.OleDb;
namespace keywordCount
{
    public partial class Form1 : Form
    {
        DataSet ds;
        OleDbDataAdapter adp;
        OleDbCommand cmd;
        Connections cns;
        OleDbConnection cn;
        Hashtable htKeywords,htKeywords1,htFns,htFns1;
        ArrayList keywords,fns;
        string libPath = @"C:\Users\VenkataSarathKumar\Dropbox\Advanced Software\ASE Literature Review\Cyclomatic complexity project\Project\keywordCount\Lib\";
        public Form1()
        {
            InitializeComponent();
            htKeywords = new Hashtable();
            htKeywords1 = new Hashtable();
            htFns = new Hashtable();
            htFns1 = new Hashtable();
            keywords = new ArrayList();
            keywords = readkeywords(libPath + "keywords.txt");

            foreach (string str in keywords)
                htKeywords.Add(str,str);
//            searchFile();           
        }
  /*      private void searchFile()
        {
            string fName = @"D:\Phd\keywordCount\keywordCount\keywords.txt";//path to text file 
            StreamReader testTxt = new StreamReader(fName);
            string allRead = testTxt.ReadToEnd();//Reads the whole text file to the end
            testTxt.Close(); //Closes the text file after it is fully read.
            string regMatch = "if";//string to search for inside of text file. It is case sensitive.
            if (allRead.Contains(regMatch))
                MessageBox.Show("Found");
            else
                MessageBox.Show("not");

            

        }*/
        private ArrayList readkeywords(string fname)
        {
            ArrayList temp=new ArrayList();
            FileStream fs = new FileStream(fname, FileMode.Open, FileAccess.Read);
            StreamReader r = new StreamReader(fs);
            r.BaseStream.Seek(0, SeekOrigin.Begin);
            
            temp.Clear();
            while (r.Peek() > -1)
               temp.Add(r.ReadLine());
            
            return temp;
        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = libPath;
            openFileDialog1.Filter = "C files (*.c)|*.c|Java files (*.java)|*.java";
            if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
                txtFile.Text = openFileDialog1.FileName.Substring(openFileDialog1.FileName.LastIndexOf(@"\")+1);
            fns = readkeywords(libPath+"stdioLib.txt");
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            /* for total keywords"*/
            richTextBox1.Clear();
            FileStream fs = new FileStream(libPath+txtFile.Text, FileMode.Open, FileAccess.Read);
            StreamReader r = new StreamReader(fs);
            r.BaseStream.Seek(0, SeekOrigin.Begin);
           char[] de = { ' ', '(', ')', '{', '}' ,'\t'};
            while (r.Peek() > -1)
            {
                string str = null;
                str = r.ReadLine();
                string[] sp = str.Split(de);
                for (int i = 0; i < sp.Length; i++)
                {
                    if (htKeywords.ContainsKey(sp[i]))
                    {


                        if (!htKeywords1.ContainsKey(sp[i]))

                            htKeywords1.Add(sp[i], 1);

                        else
                        {
                            object v = htKeywords1[sp[i]];
                            htKeywords1.Remove(sp[i]);
                            htKeywords1.Add(sp[i], int.Parse(v.ToString()) + 1);
                        }

                    }
                        
                    }
            }

            foreach (DictionaryEntry d in htKeywords1)
 
                
                richTextBox1.Text += d.Key +"\t"+d.Value+ "\n";
             
        }
        private bool isOperator(string s)
        { 
        switch(s)
            {
                case "+":
            case "-":
            case "*":
            case "/":
            case "=":return true;
            default: return false;
            
            }


        }
        private bool matchfunction(string s)
        {
            
            if (fns.Contains(s))
                return true;
            else
                return false;

        }
        private void btnFunCalls_Click(object sender, EventArgs e)
        {
           cns = new Connections();
            cn = cns.connect();
             cmd = new OleDbCommand();
            
            Globals.startTime = DateTime.Now.ToString();
            FileStream fs = new FileStream(libPath+txtFile.Text, FileMode.Open, FileAccess.Read);
            StreamReader r = new StreamReader(fs);
            Stack s = new Stack();
            Boolean inFunction=false;
            //ArrayList funcalls = new ArrayList();
            string FunToken;
            string calling="",called="",str, chainstr="";
            string funname="";
            r.BaseStream.Seek(0, SeekOrigin.Begin);
           char[] de = {' ',')','{','}','\t','\n','+','-','*','/','%','=','>','_','!','&','|'};
           char[] de1 = { ' ', ')', '{', '}', '\t', '\n', '+', '-', '*', '/', '%', '=', '>', '_', '!'};
           while (r.Peek() > -1)
           {
                              
                   str = r.ReadLine();
            
               if (str.Contains(" ("))
                     {
                         str = str.Replace(" (", "(");
                     }
                   string[] sp = str.Split(de);
                   if (!inFunction && str.Contains('(') && !str.EndsWith(";"))
                   {
                       foreach (string tokens in sp)
                       {
                       //    MessageBox.Show(tokens);
                           if (tokens.Contains('('))
                           {
                               FunToken = tokens.Substring(0, tokens.IndexOf('('));
                               if (!htKeywords.Contains(FunToken))
                               {
                                   inFunction = true;
                                   funname = FunToken;
                                  if (FunToken != "")
                                   {
                                       calling = FunToken;
                                      chainstr =FunToken + "$";
                                       if (str.Contains('{'))
                                       str = str.Substring(str.IndexOf('{'), str.Length-str.IndexOf('{'));
                                       else
                                           str="";
                                   }
                               }
                           }
                           if (inFunction)  break; 
                       }
                   }
                   if (str.Contains('{'))
                       s.Push('{');
                  
                   if (inFunction && str.Contains('('))
                  
                   {
                       sp = str.Split(de);
                       foreach (string tokens in sp)
                       {
                        //   MessageBox.Show(tokens);
                           if (tokens.Contains('('))
                           {
                               FunToken = tokens.Substring(0, tokens.IndexOf('('));
                               if (FunToken =="if" || FunToken == "while" || FunToken == "for"||FunToken=="case")
                               {
                                   int aoCount = 0;
                                   //MessageBox.Show(str);
                                   string[] andor = str.Split(de1);
                                   foreach (string ao in andor)
                                       if (ao.Contains("&&") || ao.Contains("||"))
                                           aoCount++;
                                   //MessageBox.Show(aoCount.ToString());

                                   findkeywords(funname, FunToken,aoCount);
                               }

                               if (!htKeywords.Contains(FunToken) && !isOperator(FunToken) && !matchfunction(FunToken) && FunToken != ""&&FunToken!="'")
                               {
                                   chainstr += FunToken + "  ";
                                   called += FunToken + " ";
                               }

                               //MessageBox.Show(FunToken);
                           }
                       }
                   }
                   if (str.Contains('}'))
                   {
                       s.Pop();
                       if (s.Count == 0)
                       {
                           inFunction = false;
                             Globals.funcalls.Add(chainstr);
                             called = called.Trim();
                             insFuncalls(calling, called);
                           // MessageBox.Show(chainstr);
                               chainstr = "";
                               calling = "";
                               called = "";
      
                       }
                   }                         
             }

           pruneFunCalls();
            Globals.endTime = DateTime.Now.ToString();
           ChainOfFunCalls ch = new ChainOfFunCalls();
           ch.Show();
           this.Hide();
            }
        private void pruneFunCalls()
        {
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select * from funcalls", cn);
            ds = new DataSet();
            adp.Fill(ds);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            { 
                string clstr=ds.Tables[0].Rows[i][0].ToString();
                string cstr=ds.Tables[0].Rows[i][1].ToString();
                string chkstr="select count(*) from funcalls where calling='"+cstr+"'";
                cmd=new OleDbCommand(chkstr,cn);
                cn.Open();
                object o=cmd.ExecuteScalar();
                cn.Close();
                int n=int.Parse(o.ToString());
                if(n==0)
                {
                chkstr="select count(*) from funcalls where calling='"+clstr+"'"; 
                cmd=new OleDbCommand(chkstr,cn);
                cn.Open();
                 o=cmd.ExecuteScalar();
                cn.Close();
                 n=int.Parse(o.ToString());
                if(n==1)
                   chkstr="update funcalls set called='EMPTY' where calling='"+clstr+"'"; 
                else
                    chkstr="delete from funcalls where calling='"+clstr+"' and called='"+ cstr+"'";

                cmd=new OleDbCommand(chkstr,cn);
                cn.Open();
                cmd.ExecuteNonQuery();
                    cn.Close();
                }
                }

            }
        private void insFuncalls(string calling, string called)
        {
            string c="";
            cns = new Connections();
            cn = cns.connect();
            if (calling != "")
            {
                string[] called1 = called.Split(' ');
                foreach (string s in called1)
                {
                    if (s == "")

                        c = "EMPTY";
                    else
                        c = s;
                        string insstr = "insert into funcalls values('" + calling + "','" + c + "')";
                        cmd = new OleDbCommand(insstr, cn);
                        cn.Open();
                        cmd.ExecuteNonQuery();

                        cn.Close();
                    
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] tab = new string[4];
            tab[0] = "funcalls";
                tab[1]="keywords";
                tab[2] = "complexity";
                tab[3] = "chaincomplexity";
            for (int i = 0; i < 4; i++)
            {
                delrecords(tab[i]);
            }

        }
        private void delrecords(string tname)
        {
            cns = new Connections();
            cn = cns.connect();
           cmd = new OleDbCommand("delete from " + tname,cn);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();

        }
        private void findkeywords(string funname, string funtoken,int aocount)
        {
            cns = new Connections();
             cn = cns.connect();
            cmd = new OleDbCommand();
            ds=new DataSet();
            string str = "Select * from keywords where filename='"+ txtFile.Text+"' and funname='" + funname + "' and keyword='" + funtoken + "'";
            adp = new OleDbDataAdapter(str,cn);
            adp.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                string str1 = "insert into keywords values('"+txtFile.Text+"','" + funname + "','" + funtoken + "',"+(aocount+1)+")";
                cmd.CommandText = str1;
                cmd.Connection = cn;
                cn.Open();
             //   cmd.ExecuteNonQuery();
                cn.Close();

            }
            else
            { 
                int c=int.Parse(ds.Tables[0].Rows[0][3].ToString());
                c += (aocount+1);
            string str1 = "update keywords set kcount="+ c +" where filename='"+ txtFile.Text+"' and funname='" + funname + "' and keyword='" + funtoken + "'";
                cmd.CommandText = str1;
                cmd.Connection = cn;
                cn.Open();
                cmd.ExecuteNonQuery();
                    cn.Close();
                
            }
        }

        }
}