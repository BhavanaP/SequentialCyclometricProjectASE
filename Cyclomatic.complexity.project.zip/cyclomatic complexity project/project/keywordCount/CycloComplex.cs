﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
namespace keywordCount
{
    public partial class CycloComplex : Form
    {
        Connections cns;
        OleDbCommand cmd;
        OleDbConnection cn;
        OleDbDataAdapter adp;
        DataSet ds;
        public CycloComplex()
        {
            InitializeComponent();
        }

        private void btnIndividual_Click(object sender, EventArgs e)
        {
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select distinct calling from funcalls", cn);
            
            ds = new DataSet();
            ds.Clear();
            adp.Fill(ds);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                int c = FindComplexity(ds.Tables[0].Rows[i][0].ToString());

                string insstr = "insert into complexity values('" + ds.Tables[0].Rows[i][0].ToString() + "'," + c + ")";

                cmd = new OleDbCommand(insstr, cn);
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();

            }
            showingrid();
        }
        private void showingrid()
        {
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select * from complexity", cn);
            ds = new DataSet();
            ds.Clear();
            adp.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            Globals.nofuns = ds.Tables[0].Rows.Count;
            Globals.initializeArray();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Globals.funname[i] = ds.Tables[0].Rows[i][0].ToString();
                Globals.simpleCyclo[i]=int.Parse(ds.Tables[0].Rows[i][1].ToString());
            }
        }
        private void showingrid2()
        {
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select funname , cyclomatic from chaincomplexity", cn);
            ds = new DataSet();
            ds.Clear();
            adp.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
           
             Globals.chainCyclo[i] = int.Parse(ds.Tables[0].Rows[i][1].ToString());
            
        }
        private int FindComplexity(string funname)
        {
            int c;
            cns = new Connections();
            cn = cns.connect();
            cmd= new OleDbCommand("select sum(kcount) from keywords where funname='"+ funname+"'", cn);
            cn.Open();
            object o = cmd.ExecuteScalar();
            if (o.ToString()!="")
            {
                c = int.Parse(o.ToString());
                c = c + 1;
            }
            else
                c = 1;
                 
            cn.Close();
            return c;
        }
        private void btnChain_Click(object sender, EventArgs e)
        {
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select distinct calling from funcalls", cn);
            
            ds = new DataSet();
            ds.Clear();
            adp.Fill(ds);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                getCalledFns(ds.Tables[0].Rows[i][0].ToString());
            showingrid2();
        }
        private void getCalledFns(string calling)
        {
            int totComplex = FindComplexity(calling);
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select called from funcalls where calling='"+calling+"'", cn);
            DataSet ds1 = new DataSet();
            ds1.Clear();
            adp.Fill(ds1);
            for(int i=0;i<ds1.Tables[0].Rows.Count;i++)
            {
            if(ds1.Tables[0].Rows[i][0].ToString()!="EMPTY")
                totComplex += FindComplexity(ds1.Tables[0].Rows[i][0].ToString());
            }   

            string insstr = "insert into chaincomplexity values('" + calling + "'," + totComplex + ")";

            cmd = new OleDbCommand(insstr, cn);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();

            
        
        }

        private void CycloComplex_Load(object sender, EventArgs e)
        {
            cns = new Connections();
            cn = cns.connect();
            adp = new OleDbDataAdapter("select calling,called,count(*) from funcalls where called<>'EMPTY' group by calling,called", cn);
            DataSet ds1 = new DataSet();
            ds1.Clear();
            adp.Fill(ds1);
            dataGridView3.DataSource = ds1.Tables[0];
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            charts c = new charts();
            c.Show();
            this.Hide();
        }
    }
}