﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace keywordCount
{
    public partial class ChainOfFunCalls : Form
    {
        public ChainOfFunCalls()
        {
            InitializeComponent();
        }

        private void ChainOfFunCalls_Load(object sender, EventArgs e)
        {
            Connections cns = new Connections();
            OleDbConnection cn = cns.connect();
            OleDbDataAdapter adp = new OleDbDataAdapter("select * from keywords", cn);
            DataSet ds = new DataSet();
            OleDbCommand cmd = new OleDbCommand();
            adp.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            //rtbFunCalls.Text = "Calling          $   Called\n";
            adp = new OleDbDataAdapter("select * from funcalls", cn);
            DataSet ds1 = new DataSet();
            adp.Fill(ds1);
            dataGridView2.DataSource = ds1.Tables[0];


            //foreach (string dd in Globals.funcalls)

              //  rtbFunCalls.Text += dd + "\n";
            lblstartTime.Text = Globals.startTime;
            lblEndTime.Text = Globals.endTime;
       
        }

        private void btnCycloComplex_Click(object sender, EventArgs e)
        {
            CycloComplex cc = new CycloComplex();
            cc.Show();
            this.Hide();
        }
    }
}
