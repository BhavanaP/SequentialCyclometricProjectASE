﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace keywordCount
{
    public class Connections
    {
        public OleDbConnection connect()
        {
            string str = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\VenkataSarathKumar\\Desktop\\Project4\\Database1.accdb;Persist Security Info=False";
            OleDbConnection cn = new OleDbConnection(str);
            return cn;
        }

    }
}
