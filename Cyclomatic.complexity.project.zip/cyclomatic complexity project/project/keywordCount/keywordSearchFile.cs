using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace searchTxtFile
{
    class searchTxt
    {
        static void Main()
        {
            string fName = @" ";//path to text file
            StreamReader testTxt = new StreamReader(fName);
            string allRead = testTxt.ReadToEnd();//Reads the whole text file to the end
            testTxt.Close(); //Closes the text file after it is fully read.
            string regMatch = " ";//string to search for inside of text file. It is case sensitive.
            if (Regex.IsMatch(allRead,regMatch))//If the match is found in allRead
            {
                Console.WriteLine("found\n");

            }
            else
            {
                Console.WriteLine("not found\n");
            }

        }
    }
}
