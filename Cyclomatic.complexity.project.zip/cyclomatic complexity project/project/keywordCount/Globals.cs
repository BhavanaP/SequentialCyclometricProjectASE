﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace keywordCount
{
    public class Globals
    {
        public static int nofuns;
        public static ArrayList funcalls = new ArrayList();
        public static string startTime, endTime;
        public static string[] funname;
        public static int[] simpleCyclo;
        public static int[] chainCyclo;
        public static void initializeArray()
        {
        funname = new string[nofuns];
        simpleCyclo = new int[nofuns];
        chainCyclo = new int[nofuns];
    }
    }
}
