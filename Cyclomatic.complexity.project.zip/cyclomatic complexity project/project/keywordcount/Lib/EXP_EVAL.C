#include <stdio.h>
#include <math.h>
#include <ctype.h>
typedef int (*CharIterator)(void*);
typedef enum { TokNone, TokNumber, TokSymbol,
						TokString, TokWord ,TokComment } TokenType;
typedef struct
{
	void *hook;
	CharIterator source;
	int tRow,tCol;
	int row,col;
	int current;
	TokenType type;
	int allocSpace;
	char *token;
	char *errorMessage;
} Tokenizer;

void addError (Tokenizer *tok, char *msg,int row, int col)
{
	char *tmp="", *nBuf;
	if (!tok->errorMessage) tok->errorMessage = tmp;
	nBuf = (char*)malloc(strlen(tok->errorMessage)+strlen(msg)+25);
	if (row<0 && col<0)
		sprintf(nBuf,"%s%s\n",tok->errorMessage,msg);
	else sprintf(nBuf,"%s%s at row %d, column %d\n",tok->errorMessage,msg,row,col);
	if (tok->errorMessage!=tmp) free (tok->errorMessage);
	tok->errorMessage = nBuf;
}

void ensureMem (Tokenizer *tok, int pos)
{
	char *mem;
	if (pos>=tok->allocSpace-4)
	{
		tok->allocSpace+=30;
		mem = (char*)malloc(tok->allocSpace);
		memcpy(mem,tok->token,pos);
		free(tok->token);
		tok->token = mem;
	}
}

int readChar (Tokenizer *tok)
{
	tok->current = tok->source(tok->hook);
	if (tok->current=='\n')
	{
		tok->tCol = 0;
		tok->tRow++;
	}
	else tok->tCol++;
	return tok->current;
}

const char *knownGroup[] = {
	"<=",">=","!=","==","**","+=","-=","*=","/=","<<",">>","%=","++","--",
	"^=", "|=","&=","&&","||","~=","::","<<=",">>=" };
const int nbrKnownGroup = sizeof(knownGroup)/sizeof(*knownGroup);

TokenType readTokenAndComment (Tokenizer *tok)
{
	int cc = 0, i;
	while (tok->current && isspace(tok->current)) readChar(tok);
	tok->row = tok->tRow;
	tok->col = tok->tCol;
	if (tok->current=='\"' || tok->current=='\'')
	{
		i = tok->current;
		readChar(tok);
		while (tok->current && tok->current!=i)
		{
			if(tok->current=='\\')
			{
				readChar(tok);
				if (tok->current=='n') tok->current = '\n';
				else if (tok->current=='t') tok->current = '\t';
				else if (tok->current=='r') tok->current = '\r';
			}
			ensureMem(tok,cc);
			tok->token[cc++] = tok->current;
			readChar(tok);
		}
		tok->type = TokString;
		if (tok->current==i) readChar(tok);
		else addError (tok,"String not closed",tok->row,tok->col);
	}
	else if (tok->current=='_'||isalpha(tok->current))
	{
		tok->type = TokWord;
		while (tok->current&&(tok->current=='_'||isalnum(tok->current)))
		{
			ensureMem(tok,cc);
			tok->token[cc++] = tok->current;
			readChar(tok);
		}
	}
	else if (tok->current=='.'||isdigit(tok->current))
	{
		tok->token[cc++] = tok->current;
		readChar(tok);
		if (tok->token[0]=='.' && !isdigit(tok->current))
			tok->type = TokSymbol;
		else
		{
			if (tok->token[0]!='.')
			{
				while (tok->current && isdigit(tok->current))
				{
					ensureMem(tok,cc);
					tok->token[cc++] = tok->current;
					readChar(tok);
				}
				if (tok->current=='.')
				{
					tok->token[cc++] = tok->current;
					readChar(tok);
				}
			}
			while (tok->current && isdigit(tok->current))
			{
				ensureMem(tok,cc);
				tok->token[cc++] = tok->current;
				readChar(tok);
			}
			if (tolower(tok->current)=='e')
			{
				tok->token[cc++] = tok->current;
				readChar(tok);
				if (tok->current=='+'||tok->current=='-')
				{
					tok->token[cc++] = tok->current;
					readChar(tok);
				}
				while (tok->current && isdigit(tok->current))
				{
					ensureMem(tok,cc);
					tok->token[cc++] = tok->current;
					readChar(tok);
				}
			}
			tok->type = TokNumber;
		}
	}
	else if (tok->current)
	{
		tok->type = TokSymbol;
		tok->token[cc++] = tok->current;
		readChar(tok);
		tok->token[1] = tok->current;
		tok->token[2] = 0;
		if (!strcmp(tok->token,"//"))
		{
			while (tok->current && tok->current!='\n')
			{
					ensureMem(tok,cc);
					tok->token[cc++] = tok->current;
					readChar(tok);
			}
			tok->type = TokComment;
		}
		else if (!strcmp(tok->token,"/*"))
		{
			while (tok->current && (cc<2 || (tok->token[cc-2]!='*'||tok->token[cc-1]!='/')))
			{
					ensureMem(tok,cc);
					tok->token[cc++] = tok->current;
					readChar(tok);
			}
			if (!tok->current) addError (tok,"Comment not closed",tok->row,tok->col);
			tok->type = TokComment;
		}
		else for (i=0;i<nbrKnownGroup;i++)
		{
			if (!strcmp(tok->token,knownGroup[i]))
			{
				readChar(tok);
				tok->token[++cc] = tok->current;
				tok->token[cc+1] = 0;
			}
		}
	}
	else
	{
		tok->type = TokNone;
	tok->token[cc] = 0;
	return tok->type;
	}
}

TokenType readToken (Tokenizer *tok)
{
	TokenType ret;
	do
	{
		ret = readTokenAndComment(tok);
	} 
	while (ret==TokComment);
	return ret;
}

void initTokenizer (Tokenizer *tok,CharIterator source,void *hook)
{
	tok->source = source;
	tok->hook = hook;
	tok->tRow = 1;
	tok->tCol = 0;
	tok->allocSpace = 32;
	tok->errorMessage = NULL;
	tok->token = (char*)malloc(tok->allocSpace);
	readChar(tok);
	readToken(tok);
}

void freeTokenizer(Tokenizer *tok)
{
	if (tok->errorMessage) free (tok->errorMessage);
	free(tok->token);
}

int exPlus(Tokenizer *tok,double *dRes,char *strRes,int sz);

double fnSin (double x){ return sin(x); }
double fnCos (double x){ return cos(x); }
double fnTan (double x){ return tan(x); }
double fnSqrt (double x){ return sqrt(x); }
double fnAbs (double x){ return fabs(x); }

typedef double(*ImpFunction)(double);

const struct
{
	char *name;
	ImpFunction fn;
} lstImpFunction [] =
{
	{ "sin",fnSin },
	{ "cos",fnCos },
	{ "tan",fnTan },
	{ "sqrt",fnSqrt },
	{ "abs",fnAbs }
};
const int nbrImpFunction = sizeof(lstImpFunction)/sizeof(*lstImpFunction);

int exSimple(Tokenizer *tok,double *dRes,char *strRes, int sz)
{
	int ret,i;
	if (tok->type==TokNumber)
	{
		sscanf(tok->token,"%lf",dRes);
		readToken(tok);
		return TokNumber;
	}
	else if (tok->type==TokString)
	{
		strncpy(strRes,tok->token,sz);
		readToken(tok);
		return TokString;
	}
	else if (tok->token[0]=='(')
	{
		readToken(tok);
		ret = exPlus(tok,dRes,strRes,sz);
		if (tok->token[0]==')') readToken(tok);
		else addError (tok,"parenthesis not closed ",tok->row,tok->col);
		return ret;
	}
	else if (!strcmp(tok->token,"+")||!strcmp(tok->token,"-"))
	{
		i = tok->token[0];
		readToken(tok);
		ret = exSimple(tok,dRes,strRes,sz);
		if (ret!=TokNumber)
			addError (tok,"invalid operand",tok->row,tok->col);
		else if (i=='-')
			*dRes = -*dRes;
		return ret;
	}
	else if (tok->type==TokWord)
	{
		for (i=0;i<nbrImpFunction;i++)
			if (!strcmp(lstImpFunction[i].name,tok->token)) break;
		if (i<nbrImpFunction)
		{
			readToken(tok);
			if (exSimple(tok,dRes,strRes,sz)!=TokNumber) return TokNone;
			*dRes = lstImpFunction[i].fn(*dRes);
			return TokNumber;
		}
		else addError (tok,"Unknown identifier",tok->row,tok->col);
	}
	else addError (tok,"Syntax error",tok->row,tok->col);
	return TokNone;
}

int exMult(Tokenizer *tok,double *dRes,char *strRes, int sz)
{
	int op,ret;
	double val;
	ret = exSimple(tok,dRes,strRes,sz);
	if (ret!=TokNone && ret!=TokNumber && (!strcmp(tok->token,"*")||!strcmp(tok->token,"/")))
		addError (tok,"Invalid operand to multiplying operator",tok->row,tok->col);
	while (!strcmp(tok->token,"*")||!strcmp(tok->token,"/"))
	{
		op = tok->token[0];
		readToken(tok);
		ret = exSimple(tok,&val,strRes,sz);
		if (ret!=TokNumber)
		{
			if (ret==TokNone) break;
			addError (tok,"Invalid operand to multiplying operator",tok->row,tok->col);
		}
		if (op=='*') *dRes *= val;
		else *dRes /= val;
	}
	return ret;
}

int exPlus(Tokenizer *tok,double *dRes,char *strRes, int sz)
{
	int op,ret,ret2;
	double val;
	char *sVal;
	ret = exMult(tok,dRes,strRes,sz);
	if (ret!=TokNone && ret!=TokNumber && ret!=TokString && (!strcmp(tok->token,"+")||!strcmp(tok->token,"-")))
		addError (tok,"Invalid operand to adding operator",tok->row,tok->col);
	if (ret!=TokNumber && ret!=TokString) return ret;
	sVal = (char*)malloc(sz);
	while (!strcmp(tok->token,"+")||!strcmp(tok->token,"-"))
	{
		op = tok->token[0];
		readToken(tok);
		ret2 = exMult(tok,&val,sVal,sz);
		if (ret!=ret2)
		{
			if (ret2!=TokString && ret2!=TokNumber)
			{
				if (ret2==TokNone) break;
				addError (tok,"Invalid operand to adding operator",tok->row,tok->col);
			}
			if (ret==TokNumber)
				sprintf(strRes,"%lf",*dRes);
			else sprintf(sVal,"%lf",val);
			ret = TokString;
		}
		if (ret==TokString)
		{
			if (strlen(strRes)+strlen(sVal)<sz)
				strcat(strRes,sVal);
		}
		else
		{
			if (op=='+') *dRes += val;
			else *dRes -= val;
		}
	}
	free (sVal);
	return ret;
}

int stringIterator(void*ptr)
{
	char **c = ptr;
	if (!**c)return 0;
	return *((*c)++);
}

int fileIterator(void*ptr)
{
	int x = getc ((FILE*)ptr);
	if (x==EOF) return 0;
	return x;
}

int main(int argc, char *argv[])
{
	char result[256] = "";
	double dRes;
	int status;
	Tokenizer tok;
	FILE *in = NULL;

	if (argc==1)
		initTokenizer(&tok,fileIterator,stdin);
	else
	{
		in = fopen(argv[1],"r");
		if (!in)
		{
			fprintf(stderr,"File not found: %s\n",argv[1]);
			return -1;
		}
		initTokenizer(&tok,fileIterator,in);
	}
	status = exPlus(&tok,&dRes,result,sizeof(result));
	
	if (status==TokString)
		printf("string res: %s\n",result);
	else if (status==TokNumber) printf("result: %lf\n",dRes);
	freeTokenizer(&tok);
	if (in) fclose(in);
	return 0;

}
